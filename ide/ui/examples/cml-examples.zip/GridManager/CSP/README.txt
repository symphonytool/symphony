The intended objective of this folder is reasoning about modelling this case
study with full tool support. We will later create a translated version from
SysML to CML.

We will investigate this case study with the following in mind [Richard]:
1. What are the requirements for a good case study for FT work
2. What do we want to do with a case study
3. What modelling do we want to do with the case study
4. Then analyze the GrigManager case study against these
