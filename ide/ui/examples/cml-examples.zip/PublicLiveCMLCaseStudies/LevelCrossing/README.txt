Author: 


This example is based on Bill Roscoe's CSP specification of a level railroad crossing.


Language Version: cml