Author: Peter Gorm Larsen


This is the standard stack example written in CML. If you wish to play with this you can add an invariant to put a limit to the stack size.



Language Version: cml