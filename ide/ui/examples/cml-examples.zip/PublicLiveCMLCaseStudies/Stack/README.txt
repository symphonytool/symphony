This is the standard stack example written in CML. If you wish to play with this you can add an invariant to put a limit to the stack size.

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR=Peter Gorm Larsen 
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=false 
#FORMULA=false
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=Main 
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************

