Author: Paolo Casoto, Andr� Didier and Adalberto Cajueiro


This example shows a more realistic case of an ERS (Emergency Response System) with detailed communications faults.


Language Version: cml