Author: Klaus Kristensen


This is an example produced entirely inside the COMPASS project. The example illustrates the discovery protocol for new audio / video equipment when new devices are turned on/off. 



Language Version: cml