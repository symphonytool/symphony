This example is the frog jumping puzzle that was used in the 
introductionary CSP training of CSP at the first COMPASS meeting.
This example illustrates a lot of invariants but no concurrency.
The CML model is written by Jim Woodcock.

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR= Jim Woodcock
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=false
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=Frogs 
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************

