Author: Jim Woodcock


This example is the frog jumping puzzle that was used in the 
introductionary CSP training of CSP at the first COMPASS meeting.
This example illustrates a lot of invariants but no concurrency.
The CML model is written by Jim Woodcock.



Language Version: cml