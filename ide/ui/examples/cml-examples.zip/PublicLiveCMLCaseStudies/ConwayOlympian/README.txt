This example illustrate Conways game of life (see http://en.wikipedia.org/wiki/Conway's_Game_of_Life) which has has interesting emergent properties. A VDM-SL version of this example was produced by Nick Battle and Peter Gorm Larsen and Claus Ballegaard Nielsen produced a graphical user interface showing the evolution of life following the rules of the game of life. The universe of the Game of Life is an infinite two-dimensional orthogonal grid of square cells, each of which is in one of two possible states, alive or dead. Every cell interacts with its eight neighbours, which are the cells that are horizontally, vertically, or diagonally adjacent. At each step in time, the following transitions occur:
1.Any live cell with fewer than two live neighbours dies, as if caused by under-population.
2.Any live cell with two or three live neighbours lives on to the next generation.
3.Any live cell with more than three live neighbours dies, as if by overcrowding.
4.Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.
A CML version of this was produced by Peter Gorm Larsen but no graphical user interface is available at this stage. In addition, this CML model does not yet have any any reactive bahaviour so it cannot be animated in the Symphony tool at this stage.

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR= Peter Gorm Larsen, Claus Ballegaard Nielsen and Nick Battle
#LANGUAGE_VERSION=cml 
#INV_CHECKS=false
#POST_CHECKS=false 
#PRE_CHECKS=false
#DYNAMIC_TYPE_CHECKS=false 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=false 
#FORMULA=false
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=AccountSys 
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************

