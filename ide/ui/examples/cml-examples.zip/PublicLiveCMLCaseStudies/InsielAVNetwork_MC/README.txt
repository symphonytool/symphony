This example was provided by Zoe Andrews and Jeremy Bryans and modified by Adalberto Cajueiro. 
It models the AV network, keeping renderers in synchronisation.  

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR=Zoe Andrews and Jeremy Bryans
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=true
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=OneLimiter
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************
