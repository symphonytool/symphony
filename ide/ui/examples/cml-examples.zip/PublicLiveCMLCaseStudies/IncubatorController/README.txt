This example comes from the book "Formal Software Development: From VDM to Java" written by Quentin Charatan and Aaron Kans. This example illustrate how to model an incubator controller at a very abstract level. The CML model of this has been produced by Jim Woodcock. The basic incubation controller example is simply a device that continually monitors and controls a temperature that either can be increased with an Increment operation or decreased with a Decrement operation. This example illustrate the use of guards since there is a minimum and a maximum temperature. Whenever the inc and dec channels are used the temperature represented with the state component temp is incremented and decremented by one. Pre and post-conditions are also incorporated in this example.

The IncubatorController process can be debugged but no input is expected from the user at all (except for choosing to go up or down in temperature). Note that you also can set breakpoints and inspect the temp variable when the simulation is stopped at such breakpoints. Note also that it is easy to reach a deadlock by giving a value outside the state invariant. Try it and find out how to repair this.

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR= Quentin Charatan and Aaron Kans
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=false
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=IncubatorController 
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************
