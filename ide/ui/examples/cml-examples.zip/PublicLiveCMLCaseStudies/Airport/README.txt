This example comes from the book "Formal Software Development: From VDM to Java" written by Quentin Charatan and Aaron Kans. This example illustrate how to model the air traffic control of an airport at a very high level of abstraction. The CML model has been made by Jim Woodcock including adding the reactive behaviour.

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR= Quentin Charatan and Aaron Kans
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=false
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=AccountSys 
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************

