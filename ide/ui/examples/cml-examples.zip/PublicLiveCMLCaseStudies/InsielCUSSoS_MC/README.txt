This example was provided by Paolo and modified by Adalberto Cajueiro. 
It represents the CUSSos model from Insiel.  

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR=Paolo
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=true
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=CUSSoS
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************
