Author: Paolo


This example was provided by Paolo and modified by Adalberto Cajueiro. 
It represents the CUSSos model from Insiel.  


Language Version: cml