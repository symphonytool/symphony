This example shows processes that communicate data from infinite domains. 
It is useful to show how the CML model checker is able to provide results whereas traditional
tools (like FDR and PAT) are not. 

For the process P, it is required that the user modify the Model Checker Setup preferences to 2, so 
the model checker instantiates two integers that are sufficient to produce a deadlock.

For the recursive process PRec, only one instance of natural numbers communicated in each channel 
(possibly different) is enough to produce a deadlock. Thus, it is required that the user 
modify the Model Checker Setup preferences to 1.

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR=Adalberto Cajueiro
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=true
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=PRec
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************
