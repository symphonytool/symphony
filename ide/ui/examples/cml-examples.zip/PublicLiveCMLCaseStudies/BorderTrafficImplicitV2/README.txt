Author: 


This example models the traffic flow of a border crossing between two countries in implicit style.


Language Version: classic