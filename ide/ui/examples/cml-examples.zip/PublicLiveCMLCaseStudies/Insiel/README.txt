This folder contains versions for Insiel's model put in 
SVN\...\Theme2\WP24\T2.4.2\D24.2\src-formal\insielImpl.cml which is result of applying 
SysML -> CML translation rules. 

The changes are necessary do adjust the model so the model checker can analyse it. 
