Author: Quentin Charatan and Aaron Kans


This example comes from the book "Formal Software Development: From VDM to Java" written by Quentin Charatan and Aaron Kans. This example illustrate how to model bank accounts and transactions made on these as a series of deposits and withdrawals. The CML model has been made by Peter Gorm Larsen. This example illustrate the use of records with invariants and
a state with the bank accounts indexed over the account number. All the operations are
defined implicitly. However the reactive part is not defined so that is left as an exercise for the reader. 



Language Version: cml