This simple dining philosophers models the classical example considering two philosofers.

The deadlock found by the model checker produced the same trace in the animator (except for the tau-events).
A good exercise it to run these two plugins to observe the results.  

#******************************************************
#  AUTOMATED TEST SETTINGS
#------------------------------------------------------
#AUTHOR=Adalberto Cajueiro
#LANGUAGE_VERSION=cml 
#INV_CHECKS=true 
#POST_CHECKS=true 
#PRE_CHECKS=true 
#DYNAMIC_TYPE_CHECKS=true 
#SUPPRESS_WARNINGS=false 
#POG=true 
#ISABELLE=true 
#FORMULA=true
#RTTESTER=false 
#FAULTANALYSIS=false
#MAIN_PROCESS=Dphils
#EXPECTED_RESULT=NO_ERROR_TYPE_CHECK
#******************************************************
